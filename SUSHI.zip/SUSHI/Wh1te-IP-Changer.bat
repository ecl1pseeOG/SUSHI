@echo off
title Wh1te IP Changer
color 0a

:: Inform the user what the script does
echo This script will release and renew your IP address.
echo.

:: Release the current IP address
echo Releasing the current IP address...
ipconfig /release
echo.

:: Wait for a moment
timeout /t 5 /nobreak

:: Renew the IP address
echo Renewing the IP address...
ipconfig /renew
echo.

:: Display the current IP configuration
echo Displaying the updated IP configuration...
ipconfig

pause
